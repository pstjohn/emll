import numpy as np

from .linlog_model import LinLogModel

from test_models import (load_teusink, load_mendes, load_textbook,
                         load_greene_small, load_greene_large, load_contador)

def test_linlog():

    for model_loader in (load_teusink, load_mendes, load_textbook,
                         load_greene_small, load_greene_large, load_contador):

        model, N, v_star = model_loader()

        # Create perturbation matricies
        Ex = -N.T

        boundary_indexes = [model.reactions.index(r) for r in
                            model.reactions.query(lambda x: x.boundary, None)]
        boundary_directions = [1 if r.products else -1 for r in
                               model.reactions.query(
                                   lambda x: x.boundary, None)]
        ny = len(boundary_indexes)
        Ey = np.zeros((N.shape[1], ny))

        for i, (rid, direction) in enumerate(zip(boundary_indexes,
                                                 boundary_directions)):
            Ey[rid, i] = direction

        y_hat = np.ones(ny)
        y_hat[1] -= 0.2

        e_hat = np.ones(N.shape[1])
        e_hat[v_star.argmax()] *= 1.2

        x_star = 2 * np.ones(N.shape[0])

        # Set up class
        sc = LinLogModel(N, Ex, Ey, v_star, x_star, smallbone=False)

        # Test conversion methods
        v_test = 1E-1 * np.random.randn(sc.nr)
        delta_z = sc.z_star + sc.Nr @ v_test
        delta_x = sc.x_star + sc.N @ v_test
        assert np.allclose(sc.z_to_x_alt(delta_z), delta_x)

        # Test conversion methods
        ll = LinLogModel(N, Ex, Ey, v_star, x_star, smallbone=True)

        # Test matrix steady-state
        x_ss_mat = ll.calc_xs_mat(e_hat, y_hat)
        z_ss_mat = ll.calc_zs_mat(e_hat, y_hat)

        assert np.all(np.isfinite(x_ss_mat))
        assert np.all(np.isfinite(z_ss_mat))

        # Test jacovian method equivalence
        pjac_full = ll.calc_jacobian_full_ode(x_ss_mat, e_hat, y_hat)
        pjac_red = ll.calc_jacobian_reduced_ode(z_ss_mat, e_hat, y_hat)
        pjac_mat = ll.calc_jacobian_mat(z_ss_mat, e_hat, y_hat)

        assert np.allclose(pjac_red, pjac_mat)

        ojac_red = ll.calc_jacobian_reduced_ode(
            ll.z_star, np.ones(ll.nr), np.ones(ll.ny))
        ojac_mat = ll.calc_jacobian_mat(
            ll.z_star, np.ones(ll.nr), np.ones(ll.ny))

        assert np.allclose(ojac_red, ojac_mat)

        # Test flux method equivalence
        assert np.allclose(
            ll.calc_fluxes_from_x(x_ss_mat, e_hat, y_hat),
            ll.calc_fluxes_from_z(z_ss_mat, e_hat, y_hat))

        if ll.is_stable(ojac_mat):

            # check steady-state method equivalence
            x_ss_full = ll.calc_xs_full_ode(e_hat, y_hat)
            x_ss_red = ll.calc_xs_reduced_ode(e_hat, y_hat)
            x_ss_xform = ll.calc_xs_reduced_ode(e_hat, y_hat)

            assert np.allclose(x_ss_mat, x_ss_red)
            assert np.allclose(x_ss_mat, x_ss_xform)

            # Make sure fluxes are equal
            assert np.allclose(
                ll.calc_fluxes_from_x(x_ss_full, e_hat, y_hat),
                ll.calc_fluxes_from_x(x_ss_red, e_hat, y_hat))
