import numpy as np
import scipy as sp
import casadi as cs


class LinLogModel(object):

    def __init__(self, N, Ex, Ey, v_star, x_star, smallbone=True):
        """A class to handle the stochiometric analysis and matrix reduction
        required to ensure the relevant matrices are invertable.

        Parameters
        ----------
        N : np.array
            The full stoichiometric matrix of the considered model. Must be of
            dimensions MxN
        Ex : np.array
            An NxM array of the elasticity coefficients for the given linlog
            model.
        Ey : np.array
            An NxP array of the elasticity coefficients for the external
            species.
        v_star : np.array
            A length M vector specifying the original steady-state flux
            solution of the model.
        x_star : np.array
            A length N vector specifying the original steady-state metabolite
            concentrations.
        smallbone : bool
            Whether or not to apply the smallbone rank correction

        """

        self.nm, self.nr = N.shape
        self.ny = Ey.shape[1]

        assert Ex.shape == (self.nr, self.nm), "Ex is the wrong shape"
        assert Ey.shape == (self.nr, self.ny), "Ey is the wrong shape"
        assert len(v_star) == self.nr, "v_star is the wrong length"
        assert len(x_star) == self.nm, "x_star is the wrong length"

        if smallbone:
            q, r, p = sp.linalg.qr((N @ np.diag(v_star) @ Ex).T, pivoting=True)
        else:
            q, r, p = sp.linalg.qr((N).T, pivoting=True)

        # Construct permutation matrix
        self.P = np.zeros((len(p), len(p)), dtype=int)
        for i, pi in enumerate(p):
            self.P[i, pi] = 1

        # Get the matrix rank from the r matrix
        maxabs = np.max(np.abs(np.diag(r)))
        maxdim = max(N.shape)
        tol = maxabs * maxdim * np.MachAr().eps
        # Find where the rows of r are all less than tol
        self.rank = (~(np.abs(r) < tol).all(1)).sum()

        # Reorder metabolite matrices
        self.v_star = v_star
        self.x_star = self.P @ x_star
        self.z_star = self.P[:self.rank] @ x_star
        self.Ex = Ex @ self.P.T
        self.Ey = Ey

        # Construct stoichiometric and link matrices
        self.Nr = Nr = self.P[:self.rank] @ N
        self.N = self.P @ N
        self.L = (np.diag(1/self.x_star) @ self.N @ np.linalg.pinv(Nr) @
                  np.diag(self.z_star))

        # Sanity checks
        assert np.linalg.matrix_rank(Nr) == self.rank
        assert np.allclose(self.Nr @ v_star, 0)
        assert np.allclose(self.N  @ v_star, 0)
        assert np.allclose(self.L[:self.rank], np.eye(self.rank))

    def reorder_x(self, x_old):
        """Reorder original metabolites to the permuted order"""
        return self.P @ x_old

    def x_to_z(self, x):
        """Select only the independent species from a permuted metabolite
        vector"""
        return x[:self.rank]

    def z_to_x(self, z):
        """Expand an independent list of metabolites to a full vector using the
        $log(x) \\approx x - 1$ assumption"""
        chi = self.L @ np.log(z/self.z_star).T
        return np.exp(chi) * self.x_star

    def z_to_x_alt(self, z):
        """Expand an independent list of metabolites to a full vector using
        $(x/x0 - 1) = L @ (z/z0 - 1)$"""
        chi = self.L @ (z/self.z_star - 1).T
        return (chi + 1) * self.x_star

    def calc_zs_mat(self, e_hat, y_hat):
        """Calculate a the steady-state independent metabolite concentrations
        using a matrix solve method
        """

        N_hat = (np.diag(1 / self.z_star) @
                 self.Nr @ np.diag(self.v_star * e_hat))

        chi = np.linalg.solve(N_hat @ self.Ex @ self.L,
                              -N_hat @ (np.ones(self.nr) +
                                        self.Ey @ np.log(y_hat)))

        zs = self.z_star * np.exp(chi)
        return zs

    def calc_xs_mat(self, e_hat, y_hat):
        """Calculate the complete steady-state metabolite concentrations using
        a matrix solve
        """

        zs = self.calc_zs_mat(e_hat, y_hat)
        return self.z_to_x(zs)

    def _construct_full_ode(self, e_hat, y_hat):
        t = cs.SX.sym('t', 1)
        x_sym = cs.SX.sym('x', self.nm)

        v = e_hat * self.v_star * (1 + self.Ex @ cs.log(x_sym/self.x_star) +
                                   self.Ey @ np.log(y_hat))

        v_fun = cs.Function('v', [x_sym], [v])
        ode = cs.DM(self.N) @ v_fun(x_sym)

        return t, x_sym, ode

    def calc_xs_full_ode(self, e_hat, y_hat):
        """Calculate the complete steady-state metabolite concentrations by
        integrating the complete ODE matrix (without a link matrix)
        """

        t, x_sym, ode = self._construct_full_ode(e_hat, y_hat)

        integrator = cs.integrator(
            'full', 'cvodes',
            {
                't': t,
                'x': x_sym,
                'ode': ode,
            },
            {
                'tf': 2000,
                'regularity_check': True,
            })

        xs = np.array(integrator(x0=self.x_star)['xf']).flatten()

        return xs

    def _construct_reduced_ode(self, e_hat, y_hat):

        t = cs.SX.sym('t', 1)
        z_sym = cs.SX.sym('z', self.rank)

        v = e_hat * self.v_star * (
            1 + self.Ex @ self.L @ cs.log(z_sym/self.z_star) +
            self.Ey @ np.log(y_hat))

        v_fun = cs.Function('v', [z_sym], [v])

        ode = cs.DM(self.Nr) @ v_fun(z_sym)

        return t, z_sym, ode

    def calc_xs_reduced_ode(self, e_hat, y_hat):
        """Calculate the complete steady-state metabolite concentrations by
        integrating the stoichiometrically reduced ODE system
        """

        t, z_sym, ode = self._construct_reduced_ode(e_hat, y_hat)

        integrator = cs.integrator(
            'full', 'cvodes',
            {
                't': t,
                'x': z_sym,
                'ode': ode,
            },
            {
                'tf': 2000,
                'regularity_check': True,
            })

        zs = np.array(integrator(x0=self.z_star)['xf']).flatten()
        xs = self.z_to_x(zs)

        return xs

    def calc_xs_transformed_ode(self, e_hat, y_hat):
        """Calculate the complete steady-state metabolite concentrations by
        integrating the exp-transformed ODE system
        """

        t = cs.SX.sym('t', 1)
        chi_sym = cs.SX.sym('z', self.rank)

        n_hat = np.diag(1/self.z_star) @ self.Nr @ np.diag(self.v_star)
        ode = cs.diag(cs.exp(-chi_sym)) @ n_hat @ np.diag(e_hat) @ (
            np.ones(self.nr) + self.Ex @ self.L @ chi_sym +
            self.Ey @ np.log(y_hat))

        integrator = cs.integrator(
            'full', 'cvodes',
            {
                't': t,
                'x': chi_sym,
                'ode': ode,
            },
            {
                'tf': 2000,
                'regularity_check': True,
            })

        chi = np.array(integrator(x0=np.zeros(self.rank))['xf']).flatten()

        zs = np.exp(chi) * self.z_star
        xs = self.z_to_x(zs)

        return xs

    def calc_jacobian_reduced_ode(self, z, e_hat, y_hat):
        """Calculate the jacobian matrix of the reduced system using casadi at
        the given perturbated point"""

        t, z_sym, ode = self._construct_reduced_ode(e_hat, y_hat)
        ode_f = cs.Function('v', [z_sym], [ode])
        return np.array(ode_f.jacobian(0)(z)[0])

    def calc_jacobian_full_ode(self, x, e_hat, y_hat):
        """Calculate the jacobian matrix of the full system using casadi at
        the given perturbated point"""

        t, x_sym, ode = self._construct_full_ode(e_hat, y_hat)
        ode_f = cs.Function('v', [x_sym], [ode])
        return np.array(ode_f.jacobian(0)(x)[0])

    @staticmethod
    def is_stable(jac, tol=1E-10):
        """Check a jacobian matrix to ensure stability"""

        eigs = np.linalg.eigvals(jac)
        return np.all(np.real(eigs) <= tol)

    def calc_fluxes_from_z(self, z, e_hat, y_hat):
        """Calculate fluxes for a given steady-state and parameters"""

        v = e_hat * self.v_star * (1 + self.Ex @ self.L @
                                   np.log(z / self.z_star) +
                                   self.Ey @ np.log(y_hat))

        return v

    def calc_fluxes_from_x(self, x, e_hat, y_hat):
        """Calculate fluxes for a given steady-state and parameters"""

        v = e_hat * self.v_star * (1 + self.Ex @ np.log(x/self.x_star) +
                                   self.Ey @ np.log(y_hat))

        return v

    def calc_jacobian_mat(self, z, e_hat, y_hat):
        """Calculate the jacobian matrix of the reduced system via matrix
        algebra at the given perturbated point"""

        n_hat = np.diag(1/self.z_star) @ self.Nr @ np.diag(self.v_star * e_hat)
        n_hat_ex_L = n_hat @ self.Ex @ self.L
        chi = np.log(z/self.z_star)

        return (np.diag(np.exp(-chi)) @ n_hat_ex_L @ chi +
                n_hat_ex_L @ np.diag(np.exp(-chi)) +
                n_hat @ (np.ones(self.nr) + self.Ey @ np.log(y_hat)) @
                np.diag(np.exp(-chi)))
